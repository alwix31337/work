</main>
<footer class="main-footer">
    <div class="container">
        <p>© 2025 Luxe Accessories. Все права защищены.</p>
    </div>
</footer>
<script src="/acs/js/main.js"></script>
<script src="/acs/js/cart.js"></script>
<script src="/acs/js/auth.js"></script>
</body>
</html>
