<?php
session_start();
require_once __DIR__ . '/php/config/db_connect.php';

if (empty($_SESSION['cart'])) {
    header('Location: /acs/cart.php');
    exit;
}

$error = '';
$success = '';

$full_name = '';
$phone = '';
$email = '';
$address = '';

if (isset($_SESSION['client'])) {
    $full_name = $_SESSION['client']['full_name'] ?? '';
    $phone = $_SESSION['client']['phone'] ?? '';
    $email = $_SESSION['client']['email'] ?? '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if (!$full_name || !$phone || !$email || !$address) {
        $error = 'Пожалуйста, заполните все поля';
    } else {
        try {
            $pdo->beginTransaction();

            // Вставляем заказ
            $stmt = $pdo->prepare("INSERT INTO `Order` (client_name, phone, email, address, order_date) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$full_name, $phone, $email, $address]);
            $orderId = $pdo->lastInsertId();

            // Вставляем товары заказа
            $stmtItem = $pdo->prepare("INSERT INTO OrderItem (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");

            foreach ($_SESSION['cart'] as $productId => $qty) {
                $stmtProd = $pdo->prepare("SELECT price FROM Product WHERE product_id = ?");
                $stmtProd->execute([$productId]);
                $product = $stmtProd->fetch();
                if ($product) {
                    $stmtItem->execute([$orderId, $productId, $qty, $product['price']]);
                }
            }

            $pdo->commit();

            // Очистка корзины
            $_SESSION['cart'] = [];
            $_SESSION['cart_count'] = 0;

            $success = 'Спасибо за заказ! Мы свяжемся с вами в ближайшее время.';
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'Ошибка при оформлении заказа: ' . htmlspecialchars($e->getMessage());
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<h2>Оформление заказа</h2>

<?php if ($error): ?>
    <p style="color:#e74c3c; font-weight:bold;"><?=htmlspecialchars($error)?></p>
<?php endif; ?>

<?php if ($success): ?>
    <p style="color:#2ecc71; font-weight:bold;"><?=htmlspecialchars($success)?></p>
    <a href="/acs/catalog.php" class="btn-primary">Вернуться в каталог</a>
<?php else: ?>

<?php if (!isset($_SESSION['client'])): ?>
    <p>Для оформления заказа необходимо <a href="/acs/register.php">зарегистрироваться</a> или <a href="/acs/login.php">войти</a>.</p>
<?php endif; ?>

<form method="post" action="/acs/checkout.php" style="max-width:400px;">
    <label>ФИО:</label><br />
    <input type="text" name="full_name" required value="<?= htmlspecialchars($full_name) ?>" style="width:100%; padding:8px; margin-bottom:10px;" />
    <label>Телефон:</label><br />
    <input type="text" name="phone" required value="<?= htmlspecialchars($phone) ?>" style="width:100%; padding:8px; margin-bottom:10px;" />
    <label>Email:</label><br />
    <input type="email" name="email" required value="<?= htmlspecialchars($email) ?>" style="width:100%; padding:8px; margin-bottom:10px;" />
    <label>Адрес доставки:</label><br />
    <textarea name="address" required style="width:100%; padding:8px; margin-bottom:10px;"><?= htmlspecialchars($address) ?></textarea>
    <button type="submit" style="background:#e74c3c; color:#fff; padding:10px 20px; border:none; border-radius:5px; cursor:pointer;">Оформить заказ</button>
</form>

<?php endif; ?>

<?php include __DIR__ . '/includes/footer.php'; ?>
