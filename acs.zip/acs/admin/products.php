<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: auth.php');
    exit;
}

require_once __DIR__ . '/../php/config/db_connect.php';

$error = '';
$success = '';

// Удаление товара
if (isset($_GET['delete'])) {
    $deleteId = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM Product WHERE product_id = ?");
    $stmt->execute([$deleteId]);
    header('Location: products.php');
    exit;
}

// Добавление / редактирование товара
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? '';
    $name = trim($_POST['name'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $manufacturer_id = intval($_POST['manufacturer_id'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $photo = '';

    if ($name === '' || $price <= 0) {
        $error = 'Введите корректное название и цену товара.';
    } else {
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $tmpName = $_FILES['photo']['tmp_name'];
            $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($ext, $allowed)) {
                $error = 'Недопустимый формат изображения.';
            } else {
                $newFileName = uniqid('prod_') . '.' . $ext;
                $destPath = __DIR__ . '/../img/products/' . $newFileName;
                if (!move_uploaded_file($tmpName, $destPath)) {
                    $error = 'Ошибка при загрузке изображения.';
                } else {
                    $photo = $newFileName;
                }
            }
        }

        if (!$error) {
            if ($id) {
                if ($photo) {
                    $stmt = $pdo->prepare("UPDATE Product SET name=?, price=?, manufacturer_id=?, description=?, photo=? WHERE product_id=?");
                    $stmt->execute([$name, $price, $manufacturer_id, $description, $photo, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE Product SET name=?, price=?, manufacturer_id=?, description=? WHERE product_id=?");
                    $stmt->execute([$name, $price, $manufacturer_id, $description, $id]);
                }
                $success = 'Товар обновлён.';
            } else {
                $stmt = $pdo->prepare("INSERT INTO Product (name, price, manufacturer_id, description, photo) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$name, $price, $manufacturer_id, $description, $photo]);
                $success = 'Товар добавлен.';
            }
        }
    }
}

// Получаем товары и производителей (без поставщиков)
$products = $pdo->query("SELECT p.*, m.name AS manufacturer_name FROM Product p LEFT JOIN Manufacturer m ON p.manufacturer_id = m.manufacturer_id ORDER BY p.product_id DESC")->fetchAll();
$manufacturers = $pdo->query("SELECT * FROM Manufacturer ORDER BY name")->fetchAll();

// Для редактирования
$editProduct = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM Product WHERE product_id = ?");
    $stmt->execute([$editId]);
    $editProduct = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <title>Управление товарами</title>
    <link rel="stylesheet" href="/acs/css/main.css" />
</head>
<body>
<div class="container" style="margin-top:1rem;">
    <h1>Товары</h1>

    <?php if ($error): ?>
        <div style="color:#e74c3c; margin-bottom:1rem;"><?=htmlspecialchars($error)?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div style="color:#2ecc71; margin-bottom:1rem;"><?=htmlspecialchars($success)?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" style="max-width:600px; margin-bottom:2rem;">
        <input type="hidden" name="id" value="<?= htmlspecialchars($editProduct['product_id'] ?? '') ?>" />
        <label>Название:</label><br />
        <input type="text" name="name" required value="<?= htmlspecialchars($editProduct['name'] ?? '') ?>" style="width:100%; padding:8px; margin-bottom:10px;" />
        <label>Цена (руб.):</label><br />
        <input type="number" name="price" required step="0.01" min="0" value="<?= htmlspecialchars($editProduct['price'] ?? '') ?>" style="width:100%; padding:8px; margin-bottom:10px;" />
        <label>Производитель:</label><br />
        <select name="manufacturer_id" style="width:100%; padding:8px; margin-bottom:10px;">
            <option value="0">-- Не выбран --</option>
            <?php foreach ($manufacturers as $manuf): ?>
                <option value="<?= $manuf['manufacturer_id'] ?>" <?= (isset($editProduct['manufacturer_id']) && $editProduct['manufacturer_id'] == $manuf['manufacturer_id']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($manuf['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <label>Описание:</label><br />
        <textarea name="description" rows="4" style="width:100%; padding:8px; margin-bottom:10px;"><?= htmlspecialchars($editProduct['description'] ?? '') ?></textarea>
        <label>Фото (jpg, png, gif):</label><br />
        <input type="file" name="photo" accept=".jpg,.jpeg,.png,.gif" style="margin-bottom:10px;" />
        <?php if (!empty($editProduct['photo'])): ?>
            <div style="margin-bottom:10px;">
                <img src="/acs/img/products/<?= htmlspecialchars($editProduct['photo']) ?>" alt="Фото товара" style="max-width:150px; max-height:150px; border-radius:8px;" />
            </div>
        <?php endif; ?>
        <button type="submit" style="background:#e74c3c; color:#fff; padding:10px 20px; border:none; border-radius:6px; cursor:pointer;">
            <?= $editProduct ? 'Обновить' : 'Добавить' ?>
        </button>
        <?php if ($editProduct): ?>
            <a href="products.php" style="margin-left:15px; color:#999;">Отмена</a>
        <?php endif; ?>
    </form>

    <h2>Список товаров</h2>
    <table style="width:100%; border-collapse: collapse; background:#1f1f1f; color:#eee;">
        <thead>
            <tr>
                <th style="padding:10px; border-bottom:1px solid #333;">ID</th>
                <th style="padding:10px; border-bottom:1px solid #333;">Фото</th>
                <th style="padding:10px; border-bottom:1px solid #333;">Название</th>
                <th style="padding:10px; border-bottom:1px solid #333;">Цена</th>
                <th style="padding:10px; border-bottom:1px solid #333;">Производитель</th>
                <th style="padding:10px; border-bottom:1px solid #333;">Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($products as $prod): ?>
                <tr>
                    <td style="padding:10px; border-bottom:1px solid #333;"><?= $prod['product_id'] ?></td>
                    <td style="padding:10px; border-bottom:1px solid #333;">
                        <?php if (!empty($prod['photo'])): ?>
                            <img src="/acs/img/products/<?= htmlspecialchars($prod['photo']) ?>" alt="" style="width:60px; height:60px; object-fit:cover; border-radius:5px;" />
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td style="padding:10px; border-bottom:1px solid #333;"><?= htmlspecialchars($prod['name']) ?></td>
                    <td style="padding:10px; border-bottom:1px solid #333;"><?= number_format($prod['price'], 2, ',', ' ') ?> ₽</td>
                    <td style="padding:10px; border-bottom:1px solid #333;"><?= htmlspecialchars($prod['manufacturer_name'] ?? '-') ?></td>
                    <td style="padding:10px; border-bottom:1px solid #333;">
                        <a href="products.php?edit=<?= $prod['product_id'] ?>" style="color:#2ecc71; margin-right:10px;">Редактировать</a>
                        <a href="products.php?delete=<?= $prod['product_id'] ?>" onclick="return confirm('Удалить товар?');" style="color:#e74c3c;">Удалить</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <p><a href="index.php" style="display:inline-block; margin-top:20px;">← Вернуться в панель администратора</a></p>
</div>
</body>
</html>
