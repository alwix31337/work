<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: auth.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8" />
    <title>Панель администратора</title>
    <link rel="stylesheet" href="/acs/css/main.css" />
</head>
<body>
<div class="container" style="margin-top: 2rem;">
    <h1>Панель администратора</h1>
    <ul>
        <li><a href="products.php">Товары</a></li>
        <li><a href="clients.php">Клиенты</a></li>
        <li><a href="deliveries.php">Доставки</a></li>
        <li><a href="logout.php" style="color:#e74c3c;">Выйти</a></li>
    </ul>
</div>
</body>
</html>
