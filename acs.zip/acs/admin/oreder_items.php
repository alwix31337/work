<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: auth.php');
    exit;
}
require_once __DIR__ . '/../php/config/db_connect.php';

$order_id = (int)($_GET['order_id'] ?? 0);
if (!$order_id) {
    header('Location: deliveries.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT oi.*, p.name, p.photo
    FROM OrderItem oi
    LEFT JOIN Product p ON oi.product_id = p.product_id
    WHERE oi.order_id = ?
");
$stmt->execute([$order_id]);
$orderItems = $stmt->fetchAll();

$stmtOrder = $pdo->prepare("SELECT * FROM `Order` WHERE order_id = ?");
$stmtOrder->execute([$order_id]);
$order = $stmtOrder->fetch();

if (!$order) {
    header('Location: deliveries.php');
    exit;
}

include __DIR__ . '/includes/header.php';
?>

<div class="container" style="margin-top: 1rem;">
    <h1>Товары заказа #<?= $order_id ?></h1>
    <table style="width:100%; border-collapse: collapse; background:#1f1f1f; color:#eee;">
        <thead>
            <tr>
                <th style="padding:10px; border-bottom:1px solid #333;">Фото</th>
                <th style="padding:10px; border-bottom:1px solid #333;">Название</th>
                <th style="padding:10px; border-bottom:1px solid #333;">Количество</th>
                <th style="padding:10px; border-bottom:1px solid #333;">Цена за шт.</th>
                <th style="padding:10px; border-bottom:1px solid #333;">Итого</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orderItems as $item): ?>
                <tr>
                    <td style="padding:10px; border-bottom:1px solid #333;">
                        <?php if (!empty($item['photo'])): ?>
                            <img src="/acs/img/products/<?= htmlspecialchars($item['photo']) ?>" alt="" style="width:60px; height:60px; object-fit:cover; border-radius:5px;" />
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                    <td style="padding:10px; border-bottom:1px solid #333;"><?= htmlspecialchars($item['name']) ?></td>
                    <td style="padding:10px; border-bottom:1px solid #333;"><?= $item['quantity'] ?></td>
                    <td style="padding:10px; border-bottom:1px solid #333;"><?= number_format($item['price'], 2, ',', ' ') ?> ₽</td>
                    <td style="padding:10px; border-bottom:1px solid #333;"><?= number_format($item['price'] * $item['quantity'], 2, ',', ' ') ?> ₽</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <p><a href="deliveries.php" style="display:inline-block; margin-top:20px;">← Вернуться к доставкам</a></p>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
