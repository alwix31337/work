</main>
<footer class="main-footer">
    <div class="container">
        <p>© 2025 Luxe Accessories. Все права защищены.</p>
    </div>
</footer>
</body>
</html>
