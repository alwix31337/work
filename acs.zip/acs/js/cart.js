document.addEventListener('DOMContentLoaded', () => {
    // Обновление количества товара
    document.querySelectorAll('.btn-quantity').forEach(btn => {
        btn.addEventListener('click', async () => {
            const productId = btn.dataset.productId;
            const isPlus = btn.classList.contains('plus');
            const quantityElement = btn.parentElement.querySelector('.quantity-value');
            let quantity = parseInt(quantityElement.textContent);

            if (isPlus) {
                quantity++;
            } else {
                if (quantity > 1) {
                    quantity--;
                } else {
                    return; // Не позволяем уменьшить ниже 1
                }
            }

            btn.disabled = true;

            try {
                const response = await fetch('/acs/php/cart/update.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({
                        product_id: productId,
                        quantity: quantity
                    })
                });

                const result = await response.json();

                if (result.success) {
                    quantityElement.textContent = quantity;
                    const row = btn.closest('tr');
                    const price = parseFloat(row.querySelector('.price').textContent.replace(/[^\d,]/g, '').replace(',', '.'));
                    const sum = price * quantity;
                    row.querySelector('td:nth-child(4)').textContent = sum.toLocaleString('ru-RU', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }) + ' ₽';

                    document.querySelector('.total-amount').textContent = result.totalAmount.toLocaleString('ru-RU', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }) + ' ₽';

                    const cartCounter = document.getElementById('cartCounter');
                    if (cartCounter) {
                        cartCounter.textContent = result.totalCount;
                    }
                } else {
                    alert(result.message || 'Ошибка при обновлении количества');
                }
            } catch {
                alert('Ошибка сети');
            } finally {
                btn.disabled = false;
            }
        });
    });

    // Удаление товара
    document.querySelectorAll('.btn-remove-from-cart').forEach(btn => {
        btn.addEventListener('click', async () => {
            if (!confirm('Вы уверены, что хотите удалить товар из корзины?')) {
                return;
            }

            const productId = btn.dataset.productId;
            btn.disabled = true;

            try {
                const response = await fetch('/acs/php/cart/remove.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: JSON.stringify({ product_id: productId })
                });

                const result = await response.json();

                if (result.success) {
                    const row = btn.closest('tr');
                    row.remove();

                    if (document.querySelectorAll('.cart-table tbody tr').length === 0) {
                        location.reload();
                    } else {
                        document.querySelector('.total-amount').textContent = result.totalAmount.toLocaleString('ru-RU', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        }) + ' ₽';

                        const cartCounter = document.getElementById('cartCounter');
                        if (cartCounter) {
                            cartCounter.textContent = result.totalCount;
                        }
                    }
                } else {
                    alert(result.message || 'Ошибка при удалении товара');
                    btn.disabled = false;
                }
            } catch {
                alert('Ошибка сети');
                btn.disabled = false;
            }
        });
    });
});
