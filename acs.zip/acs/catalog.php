<?php
session_start();
require_once __DIR__ . '/php/config/db_connect.php';

// Обработка добавления товара в корзину — до вывода HTML
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $productId = (int)$_POST['product_id'];
    $stmt = $pdo->prepare("SELECT product_id FROM Product WHERE product_id = ?");
    $stmt->execute([$productId]);
    if ($stmt->fetch()) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        if (isset($_SESSION['cart'][$productId])) {
            $_SESSION['cart'][$productId]++;
        } else {
            $_SESSION['cart'][$productId] = 1;
        }
    }
    header('Location: /acs/catalog.php');
    exit;
}

include __DIR__ . '/includes/header.php';

// Получаем параметры поиска и фильтрации
$search = trim($_GET['search'] ?? '');
$manufacturerFilter = (int)($_GET['manufacturer'] ?? 0);
$minPrice = isset($_GET['min_price']) ? (float)$_GET['min_price'] : 0;
$maxPrice = isset($_GET['max_price']) ? (float)$_GET['max_price'] : 0;

// Формируем SQL с фильтрами
$sql = "SELECT p.*, m.name AS manufacturer_name FROM Product p LEFT JOIN Manufacturer m ON p.manufacturer_id = m.manufacturer_id WHERE 1";
$params = [];

if ($search !== '') {
    // Используем УНИКАЛЬНЫЕ плейсхолдеры для каждого LIKE
    $sql .= " AND (p.name LIKE :search_name OR m.name LIKE :search_manufacturer)";
    $params['search_name'] = "%$search%";
    $params['search_manufacturer'] = "%$search%";
}

if ($manufacturerFilter > 0) {
    $sql .= " AND p.manufacturer_id = :manufacturer";
    $params['manufacturer'] = $manufacturerFilter;
}

if ($minPrice > 0) {
    $sql .= " AND p.price >= :min_price";
    $params['min_price'] = $minPrice;
}

if ($maxPrice > 0) { // Проверяем только что он больше нуля, а сравнение с minPrice уже в SQL
    $sql .= " AND p.price <= :max_price";
    $params['max_price'] = $maxPrice;
}

$sql .= " ORDER BY p.product_id ASC";

// Подготовка и выполнение запроса
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

// Получаем список производителей для фильтра
$manufStmt = $pdo->query("SELECT manufacturer_id, name FROM Manufacturer ORDER BY name ASC");
$manufacturers = $manufStmt->fetchAll();
?>

<h2>Каталог товаров</h2>

<form method="get" action="/acs/catalog.php" style="margin-bottom: 20px; display: flex; flex-wrap: wrap; gap: 10px; align-items: center;">
    <input type="text" name="search" placeholder="Поиск по названию товара и производителю" value="<?=htmlspecialchars($search)?>" style="flex: 2; padding: 8px;" />
    <select name="manufacturer" style="flex: 1; padding: 8px;">
        <option value="0">Все производители</option>
        <?php foreach ($manufacturers as $manuf): ?>
            <option value="<?= $manuf['manufacturer_id'] ?>" <?= $manufacturerFilter == $manuf['manufacturer_id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($manuf['name']) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <input type="number" name="min_price" placeholder="Мин. цена" min="0" step="1" value="<?= $minPrice > 0 ? $minPrice : '' ?>" style="width: 100px; padding: 8px;" />
    <input type="number" name="max_price" placeholder="Макс. цена" min="0" step="1" value="<?= $maxPrice > 0 ? $maxPrice : '' ?>" style="width: 100px; padding: 8px;" />
    <button type="submit" style="background:#e74c3c; color:#fff; border:none; padding: 8px 16px; cursor:pointer; flex: 0 0 auto;">Фильтровать</button>
</form>

<div class="product-grid">
<?php
if ($stmt->rowCount() > 0) {
    while ($product = $stmt->fetch()):
?>
    <div class="product-card">
        <div class="product-image">
            <img src="/acs/img/products/<?= htmlspecialchars($product['photo']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" />
        </div>
        <div class="product-details">
            <h3><?= htmlspecialchars($product['name']) ?></h3>
            <p>Производитель: <?= htmlspecialchars($product['manufacturer_name'] ?? 'Неизвестно') ?></p>
            <p class="price"><?= number_format($product['price'], 0, ',', ' ') ?> ₽</p>
            <form method="post" action="/acs/catalog.php">
                <input type="hidden" name="product_id" value="<?= $product['product_id'] ?>" />
                <button type="submit" class="btn-add-to-cart">Добавить в корзину</button>
            </form>
        </div>
    </div>
<?php
    endwhile;
} else {
    echo "<p style='grid-column: 1 / -1; text-align: center; font-size: 1.2rem; color: #aaa;'>Товары по вашему запросу не найдены.</p>";
}
?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
