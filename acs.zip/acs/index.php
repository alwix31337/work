<?php
include __DIR__ . '/includes/header.php';
?>

<section class="hero-banner" style="
    background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('/acs/img/hero.jpg') center/cover no-repeat;
    border-radius: 15px;
    height: 450px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    text-shadow: 0 0 15px #000;
    margin-bottom: 3rem;
">
    <div style="max-width: 700px; text-align: center;">
        <h1 style="font-size: 3.5rem; margin-bottom: 1rem; font-weight: 900;">Добро пожаловать в Luxe Accessories</h1>
        <p style="font-size: 1.6rem; margin-bottom: 2rem; font-weight: 500;">
            Лучшие аксессуары для вашего стиля и комфорта. Качество, проверенное временем.
        </p>
        <a href="/acs/catalog.php" class="btn-primary" style="
            padding: 15px 40px;
            border-radius: 40px;
            font-weight: 700;
            font-size: 1.2rem;
            text-decoration: none;
            background: #e74c3c;
            color: white;
            box-shadow: 0 5px 15px rgba(231,76,60,0.6);
            transition: background 0.3s ease;
        " onmouseover="this.style.background='#c0392b'" onmouseout="this.style.background='#e74c3c'">
            Перейти в каталог
        </a>
    </div>
</section>

<section style="max-width: 900px; margin: auto; color: #ddd; font-size: 1.15rem; line-height: 1.7;">
    <h2 style="color: #e74c3c; margin-bottom: 1rem; font-weight: 700;">О нас</h2>
    <p>
        Luxe Accessories — это ваш надёжный магазин стильных и качественных аксессуаров. Мы предлагаем широкий выбор товаров для создания уникального образа и комфорта в повседневной жизни.
    </p>
    <p>
        Наша миссия — помочь вам подчеркнуть индивидуальность с помощью аксессуаров, которые сочетают в себе стиль, качество и доступность.
    </p>
    <p>
        Мы гарантируем быструю доставку, удобные способы оплаты и внимательное обслуживание каждого клиента.
    </p>
</section>

<?php
include __DIR__ . '/includes/footer.php';
