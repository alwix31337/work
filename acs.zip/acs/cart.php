<?php
session_start();
require_once __DIR__ . '/php/config/db_connect.php';

// Обработка удаления товара из корзины
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_product_id'])) {
    $removeId = (int)$_POST['remove_product_id'];
    if (isset($_SESSION['cart'][$removeId])) {
        unset($_SESSION['cart'][$removeId]);
    }
    // Перенаправляем, чтобы избежать повторной отправки формы
    header('Location: /acs/cart.php');
    exit;
}

include __DIR__ . '/includes/header.php';

$cart = $_SESSION['cart'] ?? [];

if (empty($cart)) {
    echo "<div class='empty-cart'>";
    echo "<h2>Ваша корзина пуста</h2>";
    echo "<a href='/acs/catalog.php' class='btn-primary'>Перейти в каталог</a>";
    echo "</div>";
} else {
    echo "<div class='cart-container'>";
    echo "<h2>Ваша корзина</h2>";
    echo "<table class='cart-table'>";
    echo "<thead><tr>
            <th>Товар</th>
            <th>Цена</th>
            <th>Количество</th>
            <th>Итого</th>
            <th>Действие</th>
          </tr></thead><tbody>";

    $total = 0;
    foreach ($cart as $productId => $quantity) {
        $stmt = $pdo->prepare("SELECT * FROM Product WHERE product_id = ?");
        $stmt->execute([$productId]);
        $product = $stmt->fetch();
        if (!$product) continue;

        $sum = $product['price'] * $quantity;
        $total += $sum;

        echo "<tr>";
        echo "<td>" . htmlspecialchars($product['name']) . "</td>";
        echo "<td>" . number_format($product['price'], 2, ',', ' ') . " ₽</td>";
        echo "<td>$quantity</td>";
        echo "<td>" . number_format($sum, 2, ',', ' ') . " ₽</td>";
        echo "<td>
                <form method='post' style='margin:0;'>
                    <input type='hidden' name='remove_product_id' value='$productId' />
                    <button type='submit' class='btn-remove-from-cart' title='Удалить'>
                        <i class='fas fa-trash'></i> Удалить
                    </button>
                </form>
              </td>";
        echo "</tr>";
    }

    echo "</tbody>";
    echo "<tfoot><tr><td colspan='3' class='total-label'>Итого:</td><td class='price'>" . number_format($total, 2, ',', ' ') . " ₽</td><td></td></tr></tfoot>";
    echo "</table>";
    echo "<a href='/acs/catalog.php' class='btn-continue'>Продолжить покупки</a> ";
    echo "<a href='/acs/checkout.php' class='btn-checkout'>Оформить заказ</a>";
    echo "</div>";
}

include __DIR__ . '/includes/footer.php';
